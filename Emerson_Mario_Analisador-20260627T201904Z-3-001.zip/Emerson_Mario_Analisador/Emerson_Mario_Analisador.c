//Emerson Veiga Monteiro FIlho - 21951278
//Mario Haddad Neto - 21951277

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "tokens.h"

int verifica_tipo(const char *lexema) {
    if (strcmp(lexema, "bool") == 0) {
        return KW_BOOL;
    } else if (strcmp(lexema, "int") == 0) {
        return KW_INT;
    } else if (strcmp(lexema, "char") == 0) {
        return KW_CHAR;
    } else if (strcmp(lexema, "real") == 0) {
        return KW_REAL;
    } else if (strcmp(lexema, "bool") == 0) {
        return KW_BOOL;
    } else if (strcmp(lexema, "if") == 0) {
        return KW_IF;
    } else if (strcmp(lexema, "then") == 0) {
        return KW_THEN;
    } else if (strcmp(lexema, "else") == 0) {
        return KW_ELSE;
    } else if (strcmp(lexema, "while") == 0) {
        return KW_LOOP;
    } else if (strcmp(lexema, "input") == 0) {
        return KW_INPUT;
    } else if (strcmp(lexema, "output") == 0) {
        return KW_OUTPUT;
    } else if (strcmp(lexema, "return") == 0) {
        return KW_RETURN; 
    }
    return TK_IDENTIFIER;
}

// Declaração de funções
void prox_char(FILE *arquivo_entrada);
void grava_token(FILE *saida, int token, const char *lexema);
void erro(const char *mensagem);
int verifica_tipo(const char *lexema);

// Variáveis globais
int caractere_atual;
char lexema[100];
int pos_lexema = 0;

int main() {
    FILE *arquivo_entrada;
    FILE *arquivo_saida;

    arquivo_entrada = fopen("entrada.txt", "r");
    arquivo_saida = fopen("saida.txt", "w"); 

    prox_char(arquivo_entrada); // Lê o primeiro caractere

    while (caractere_atual != EOF) {
        pos_lexema = 0;

        if (isspace(caractere_atual)) {
            // Ignora espaços, tabs e quebras de linha
            prox_char(arquivo_entrada);
        } else if (isalpha(caractere_atual)) {
            // Identificadores ou palavras reservadas
            while (isalnum(caractere_atual) || caractere_atual == '_') {
                lexema[pos_lexema++] = caractere_atual;
                prox_char(arquivo_entrada);
            }
            lexema[pos_lexema] = '\0';

            int token = verifica_tipo(lexema);

            grava_token(arquivo_saida, token, lexema);
        } else if (isdigit(caractere_atual)) {
            // Números inteiros
            while (isdigit(caractere_atual)) {
                lexema[pos_lexema++] = caractere_atual;
                prox_char(arquivo_entrada);
            }
            lexema[pos_lexema] = '\0';
            grava_token(arquivo_saida, LIT_INT, lexema);
        } else {
            // Outros símbolos
            int token;
            switch (caractere_atual) {
                case '=':
                    prox_char(arquivo_entrada);
                    if (caractere_atual == '=') {
                        grava_token(arquivo_saida, OPERATOR_EQ, "==");
                        prox_char(arquivo_entrada);
                    } else {
                        grava_token(arquivo_saida, OPERATOR_ATRIB, "=");
                        prox_char(arquivo_entrada);
                    }
                    break;
                case '<':
                    prox_char(arquivo_entrada);
                    if (caractere_atual == '=') {
                        grava_token(arquivo_saida, OPERATOR_LE, "<=");
                        prox_char(arquivo_entrada);
                    } else {
                        grava_token(arquivo_saida, OPERATOR_ATRIB, "<"); // Tratar '<' como um token separado
                    }
                    break;
                case '>':
                    prox_char(arquivo_entrada);
                    if (caractere_atual == '=') {
                        grava_token(arquivo_saida, OPERATOR_LE, ">=");
                        prox_char(arquivo_entrada);
                    } else {
                        grava_token(arquivo_saida, OPERATOR_ATRIB, ">"); // Tratar '<' como um token separado
                    }
                    break;
                case ';':
                    grava_token(arquivo_saida, SG_SEMICOLON, ";");
                    prox_char(arquivo_entrada);
                    break;
                case ',':
                    grava_token(arquivo_saida, SG_SEMICOLON, ",");
                    prox_char(arquivo_entrada);
                    break;
                case '(':
                    grava_token(arquivo_saida, SG_SEMICOLON, "(");
                    prox_char(arquivo_entrada);
                    break;
                case ')':
                    grava_token(arquivo_saida, SG_SEMICOLON, ")");
                    prox_char(arquivo_entrada);
                    break;
                case '[':
                    grava_token(arquivo_saida, SG_SEMICOLON, "[");
                    prox_char(arquivo_entrada);
                    break;
                case ']':
                    grava_token(arquivo_saida, SG_SEMICOLON, "]");
                    prox_char(arquivo_entrada);
                    break;
                case '{':
                    grava_token(arquivo_saida, SG_SEMICOLON, "{");
                    prox_char(arquivo_entrada);
                    break;
                case '}':
                    grava_token(arquivo_saida, SG_SEMICOLON, "}");
                    prox_char(arquivo_entrada);
                    break;
                case '+':
                    grava_token(arquivo_saida, SG_SEMICOLON, "+");
                    prox_char(arquivo_entrada);
                    break;
                case '-':
                    grava_token(arquivo_saida, SG_SEMICOLON, "-");
                    prox_char(arquivo_entrada);
                    break;
                case '*':
                    grava_token(arquivo_saida, SG_SEMICOLON, "*");
                    prox_char(arquivo_entrada);
                    break;
                case '/':
                    grava_token(arquivo_saida, SG_SEMICOLON, "/");
                    prox_char(arquivo_entrada);
                    break;
                case '%':
                    grava_token(arquivo_saida, SG_SEMICOLON, "%");
                    prox_char(arquivo_entrada);
                    break;
                case '&':
                    prox_char(arquivo_entrada);
                    grava_token(arquivo_saida, SG_SEMICOLON, "&");
                    prox_char(arquivo_entrada);
                    break;
                case '|':
                    grava_token(arquivo_saida, SG_SEMICOLON, "|");
                    prox_char(arquivo_entrada);
                    break;
                case '~':
                    grava_token(arquivo_saida, SG_SEMICOLON, "~");
                    prox_char(arquivo_entrada);
                    break;
                default:
                    grava_token(arquivo_saida, caractere_atual, "");
                    prox_char(arquivo_entrada);
                    break;
            }
        }
    }
    fclose(arquivo_entrada);
    fclose(arquivo_saida);
    return 0;
}

void prox_char(FILE *arquivo_entrada) {
    caractere_atual = fgetc(arquivo_entrada);
}

void grava_token(FILE *arquivo_saida, int token, const char *lexema) {
    fprintf(arquivo_saida, "Token: %d\n", token);
    if (token != SG_SEMICOLON) {
        fprintf(arquivo_saida, "Lexema: %s\n", lexema);
    } else {
        fprintf(arquivo_saida, "Lexema: %c\n", caractere_atual);
    }
}
void erro(const char *mensagem) {
    fprintf(stderr, "%s\n", mensagem);
    exit(1);
}
